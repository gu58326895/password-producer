
1.进入bin目录，打开passgen.bat执行程序。

2.如果命令行加上选项 +p 或 +P，则由ASCII码中的所有可见字符组成

3.命令行加上数字选项，用户控制生成的密码的长度

4.打开conf目录下application.propertie配置文件
  默认大小写敏感（case-sensitive = false）
  如果配置文件中打开了禁用大写字母开关（即case-sensitive = false），则生成的密码中不包含大写字母